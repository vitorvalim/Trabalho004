<?php 
include("layout/topo.php");

    
$id = $_GET['id'];
$sql = "SELECT * FROM clientes WHERE id=" . $id;

include("database/database.php");

$resultado = $con->query($sql);
$dados = $resultado ->fetch_assoc();
?>
<h1>Alterar Cadastro</h1>
<form method ="post" action="salvar_alt_cliente.php">
    <input type="hidden" name="id" value = '<?php echo $dados['id'];?>'>
<div class="form-group">
    <label>Nome do Cliente</label>
    <input type="text" name="nome" class= "form-control" placeholder="Julio Morais" value="<?php echo $dados['nome'];?>">

    </div>
<div class="form-group">
    <label>Data de Nascimento</label>
    <input type="text" name="data_nascimento" class= "form-control" placeholder="AAAAMMDD" value="<?php echo $dados['data_nascimento'];?>">

</div>
<div class="form-group">
    <label>Cidade de Nascimento</label>
    <input type="text" name="cidade_nasc" class= "form-control" placeholder="7" value="<?php echo $dados['cidade_nasc'];?>">

</div>
<div class="form-group">
    <label>Ativo</label>
    <input type="text" name="ativo" class= "form-control" placeholder="1" value="<?php echo $dados['ativo'];?>">

<button type = "submit" class = "btn btn-success">Salvar</button>
</form>

<?php
include("layout/baixo.php");
?>


