<?php

include("database\database.php");
    $nome = $_POST["nome"];
    $quantidade = $_POST["quantidade"];
    $preco = $_POST["preco"];
    $peso = $_POST["peso"];

    $sql = "INSERT INTO produto
        (nome, preco, quantidade, peso)
        VALUES
        ('{$nome}',{$preco},{$quantidade},{$peso})";
    //echo $sql;
    $con->query($sql);
    $con->close();
    header("location: index.php");
?>

<script>
    setTimeout (200000, window.location.reload)
</script>
