<?php 
include("layout/topo.php");
?>
<form method ="post" action="salvar_usuario.php">
<div class="form-group">
    <label>Nome do Usuário</label>
    <input type="text" name="nome" class= "form-control" placeholder="Julio Morais">

    </div>
<div class="form-group">
    <label>Usuáriao</label>
    <input type="text" name="usuario" class= "form-control" placeholder="Julio Morais">

</div>
<div class="form-group">
    <label>Senha</label>
    <input type="password" name="senha" class= "form-control" placeholder="*******">

</div>
<div class="form-group">
    <label>E-mail</label>
    <input type="text" name="email" class= "form-control" placeholder="abc@gmail.com">

<button type = "submit" class = "btn btn-success">Cadastrar</button>
</form>

<?php
include("layout/baixo.php");
?>


