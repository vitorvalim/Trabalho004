
<?php
//$local = '127.0.0.1:3307';
//$user = 'root';
//$pwd = '';
//$db = 'loja';

//$con = new mysqli($local, $user, $pwd, $db);    
//if ($con->connect_error) 
//{
//    echo $con->connect_error;
//}
include("layout/topo.php");

include("database/database.php");

$sql = "SELECT * FROM produto"; 

$result = $con->query($sql);

?>
<h1>Cadastro de produto</h1>

<a href='novo_produto.php' class = 'btn btn-primary'>Novo produto</a>
<a href='usuario_login.php' class = 'btn btn-primary'>Login</a>
<br>
<br>
<tbody>
<table class="table table-hover"> 
    <thead> 
        <td>Id</td>
        <td>Nome</td>
        <td>Preço</td>
        <td>Quantidade</td>
        <td>Peso</td>
        <td>Editar</td>
    </thead>
    <tbody>
    <?php
    while($row = $result->fetch_assoc())
    {
        echo'<tr>
                <td>'.$row['id'].'</td>
                <td>'.$row['nome'].'</td>
                <td>'.'R$'.$row['preco'].'</td> 
                <td>'.$row['quantidade'].'</td>
                <td>'.$row['peso']."</td>
                <td>
                    <a href= '/LPW1/Trabalho04/alterar_produto.php?id=" .$row["id"]."'>✏️</a>
                    <a href= '/LPW1/Trabalho04/excluir_produto.php?id=" .$row["id"]."'>🗑️</a>
                </td>
            </tr>";   
    }
    ?>
    </tbody>
</table>

<?php
 include("layout/baixo.php");
 $con->close();

?>
