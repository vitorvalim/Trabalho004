<?php

include("database\database.php");
$nome = $_POST['nome'];
$usuario = $_POST['usuario'];
$senha = $_POST['senha'];
$email = $_POST['email'];

    $sql = "INSERT INTO usuario
        (nome, usuario, senha, email)
        VALUES
        ('{$nome}','{$usuario}','{$senha}','{$email}')";
    //echo $sql;
    $con->query($sql);
    $con->close();
    header("location: usuario.php");
?>

<script>
    setTimeout (200000, window.location.reload)
</script>
