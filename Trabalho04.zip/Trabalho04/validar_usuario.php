<?php

session_start();

include("database/database.php");


$usuario = $_POST['usuario'];
$senha = $_POST['senha'];

 $sql = " SELECT * FROM usuario
       WHERE usuario  = '{$usuario}'
       ";
$result = $con->query($sql);
$row = $result->fetch_assoc();

$nome = $row["nome"];

$dominio = "pag_inicial.php";


if(isset($row["senha"]) && $row["senha"] == $senha)
       {                      
              //$novo_usuario = $usuario;
              //$_SESSION['Logado'] = $novo_usuario;
              //header('location: pag_inicial.php');
              @$_SESSION['login_status'] = "login_valido";
              @$_SESSION['login']['dominio'] = $dominio;
              @$_SESSION['login']['usuario'] = $usuario;
              @$_SESSION['login']['nome'] = $nome;
              
              header("location: pag_inicial.php");

       }else{
              header("location: index.php");
       }

       $con->close();
 
 ?>
