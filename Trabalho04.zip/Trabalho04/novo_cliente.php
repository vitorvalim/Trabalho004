<?php 
include("layout/topo.php");
?>
<form method ="post" action="salvar_cliente.php">
<div class="form-group">
    <label>Nome do Cliente</label>
    <input type="text" name="nome" class= "form-control" placeholder="Julio Morais">

    </div>
<div class="form-group">
    <label>Data de Nascimento</label>
    <input type="text" name="data_nascimento" class= "form-control" placeholder="AAAAMMDD">

</div>
<div class="form-group">
    <label>Cidade de Nascimento</label>
    <input type="text" name="cidade_nasc" class= "form-control" placeholder="7">

</div>
<div class="form-group">
    <label>Ativo</label>
    <input type="text" name="ativo" class= "form-control" placeholder="1">

<button type = "submit" class = "btn btn-success">Cadastrar</button>
</form>

<?php
include("layout/baixo.php");
?>


