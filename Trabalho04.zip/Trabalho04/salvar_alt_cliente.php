<?php
 $id = $_POST['id'];
 $nome = $_POST['nome'];
 $data_nascimento = $_POST['data_nascimento'];
 $cidade_nasc = $_POST['cidade_nasc'];
 $ativo = $_POST['ativo'];


 $sql = " UPDATE clientes SET nome = '{$nome}',
        data_nascimento = '{$data_nascimento}',
        cidade_nasc = {$cidade_nasc},
        ativo = {$ativo}
        WHERE id = {$id}
 ";
 include("database/database.php");
 $con->query($sql);
 header("location: cliente.php");
 
 ?>
