
<?php
//$local = '127.0.0.1:3307';
//$user = 'root';
//$pwd = '';
//$db = 'loja';

//$con = new mysqli($local, $user, $pwd, $db);    
//if ($con->connect_error) 
//{
//    echo $con->connect_error;
//}
include("layout/topo.php");
include("database/database.php");

$sql = "SELECT * FROM usuario"; 

$result = $con->query($sql);

?>
<h1>Usuarios</h1>

<a href='novo_usuario.php' class = 'btn btn-primary'>Cadastrar Usuario</a>


<br>
<br>
<tbody>
<table class="table table-hover"> 
    <thead> 
        <td>Id</td>
        <td>Nome</td>
        <td>Usuario</td>
        <td>Senha</td>
        <td>E-mail</td>

    </thead>
    <tbody>
    <?php
    while($row = $result->fetch_assoc())
    {
        echo'<tr>
                <td>'.$row['id'].'</td>
                <td>'.$row['nome'].'</td>
                <td>'.$row['usuario'].'</td>
                <td>'.$row['senha'].'</td>  
                <td>'.$row['email']."</td>
                

            </tr>";   
    }
    ?>
    </tbody>
</table>

<?php
 include("layout/baixo.php");
 $con->close();

?>
