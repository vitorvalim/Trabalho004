<?php

include("database\database.php");
$nome = $_POST['nome'];
$data_nascimento = $_POST['data_nascimento'];
$cidade_nasc = $_POST['cidade_nasc'];
$ativo = $_POST['ativo'];

    $sql = "INSERT INTO clientes
        (nome, data_nascimento, cidade_nasc, ativo)
        VALUES
        ('{$nome}','{$data_nascimento}',{$cidade_nasc},{$ativo})";
    //echo $sql;
    $con->query($sql);
    $con->close();
    header("location: cliente.php");
?>

<script>
    setTimeout (200000, window.location.reload)
</script>
