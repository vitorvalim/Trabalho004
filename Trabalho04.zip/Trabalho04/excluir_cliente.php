<?php

// n realizar incluede de topo ou baixo



$id = $_GET['id'];

$sql = "
DELETE FROM clientes
WHERE id={$id}
";

include("database/database.php");
$con->query($sql);

header("location: cliente.php");

?>
