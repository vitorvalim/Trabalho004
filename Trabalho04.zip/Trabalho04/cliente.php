
<?php
//$local = '127.0.0.1:3307';
//$user = 'root';
//$pwd = '';
//$db = 'loja';

//$con = new mysqli($local, $user, $pwd, $db);    
//if ($con->connect_error) 
//{
//    echo $con->connect_error;
//}
include("layout/topo.php");
include("database/database.php");

$sql = "SELECT * FROM clientes"; 

$result = $con->query($sql);

?>
<h1>Pagina do Cliente</h1>

<a href='novo_cliente.php' class = 'btn btn-primary'>Cadastrar-se</a>

<br>
<br>
<tbody>
<table class="table table-hover"> 
    <thead> 
        <td>Id</td>
        <td>Nome</td>
        <td>Data de Nascimento</td>
        <td>Cidade de Nascimento</td>
        <td>Ativo</td>
    </thead>
    <tbody>
    <?php
    while($row = $result->fetch_assoc())
    {
        echo'<tr>
                <td>'.$row['id'].'</td>
                <td>'.$row['nome'].'</td>
                <td>'.$row['data_nascimento'].'</td> 
                <td>'.$row['cidade_nasc'].'</td>
                <td>'.$row['ativo']."</td>
                <td>
                    <a href= '/LPW1/Trabalho04/alterar_cliente.php?id=" .$row["id"]."'>✏️</a>
                    <a href= '/LPW1/Trabalho04/excluir_cliente.php?id=" .$row["id"]."'>🗑️</a>
                </td>
            </tr>";   
    }
    ?>
    </tbody>
</table>

<?php
 include("layout/baixo.php");
 $con->close();

?>
