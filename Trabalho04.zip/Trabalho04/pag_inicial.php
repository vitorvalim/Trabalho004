<?php

              include("layout/topo.php");
              echo '<h1>'.'Bem vindo'.'</h1>';
              include("layout/baixo.php");
        
 ?>
